# 西南林业大学（SWFU）统一身份认证扩展

API v3 新正方扩展（`kind: extension`，`extends: builtin.zf`），1.1.4。

- 认证：在 App 内用**学号 + 个人门户密码**登录学校正方定制 CAS（倒序 RSA、图片验证码；
  二次认证时交接官方网页），登录后核验姓名与学号。
- 校历作息（1.1.0 新增）：`study.calendar` 调用学校「按周次课表」的接口，返回**真实的 12 节次起止时间
  和开学日期**，修正 App 默认节次时间；学期、课表、成绩、考试与选课继续复用内置新正方协议。

## 1.1.4：教务密码本地直登（绕过统一认证网络问题）

2026-11-16 学校把教务登录强制 302 到统一认证，同时 `/sso/zfiotlogin` 部分后端节点随机 404；
另外 `cas.swfu.edu.cn` 公网 IPv6 不可达，App 直连 CAS 会先等 20 秒 IPv6 超时，超过宿主登录超时。

实测发现：**教务前端虽然强制跳 CAS，但后端 `/jwglxt/xtgl/login_slogin.html` 的本地账号密码 POST 仍可用**
（`yhm` + `mm` 明文，约 2 秒建会话，只走 IPv4 的教务域名）。1.1.4 因此改为：

1. 先尝试教务本地密码直登（单请求、IPv4、约 2 秒）；
2. 本地被拒或接口关闭时，回退统一身份认证 CAS（倒序 RSA、验证码）；
3. 统一认证入口在 `/jwglxt/xtgl/login_slogin.html` 与 `/sso/zfiotlogin` 间重试，避开 /sso 的 404 抖动。

> **登录时请填「教务密码」**（本地直登通道）。若学校关闭本地接口，插件会回退 CAS，此时需填统一认证密码。

## 1.1.3：登录入口变更修复

2026-11-13 学校把 `/jwglxt/xtgl/login_slogin.html` 改成**本地密码表单（200，不再 302 到统一认证）**，
1.1.2 从该地址进入会报 `PAGE_CHANGED`。1.1.3 认证入口改为直接访问 `/sso/zfiotlogin`（仍 302 到 CAS，
登录成功后回跳教务建立会话），密码、验证码、二次认证交接逻辑不变。

同日实测：逐周（1-20 周）单周课表并集 23 条，与学期课表 23 条完全一致，无遗漏。

**真机验收（2026-11-13）**：App 1.0.135 上登录成功，课表节次时间显示为 08:20–09:05、09:10–09:55、10:25–11:10 等真实时间，周次从 2026-08-31 起算。

## 1.1.2：作息获取时序修复

宿主对单次插件调用有 5 秒预算；1.1.1 的 `study.calendar` 串行请求「周次 → 课表(取校区号) → 节次」三次，
在网络较慢时可能超时，被宿主按可重试错误丢弃，作息因此未写入、课表退回 08:00 默认值。

1.1.2 改为：

- 周次与节次请求**并行**发出（2 次请求）；
- 默认使用校本部校区号 `1`（2026-11 实测两个账号的 `kbList` 均为 1），不再为了拿校区号先拉整份课表；
- 校区号取不到时才查 `xskbcxMobile_cxXsKb.html` 后重试；
- 节次接口仍不可用时，用学校 2026-11 实测的公开作息兜底（08:20–09:05 … 共 12 节）。

真实接口回放：2 次请求返回 12 节次与开学日期，与学校页面一致。

## 实测入口与接口（2026-11-13）

| 用途 | 地址 / 接口 |
| --- | --- |
| 教务登录入口 | `https://jw.swfu.edu.cn/jwglxt/xtgl/login_slogin.html` |
| SSO 桥 | `/sso/zfiotlogin` → `https://cas.swfu.edu.cn/cas/login?service=https%3A%2F%2Fjw.swfu.edu.cn%2Fsso%2Fzfiotlogin` |
| 登录公钥 | `POST /cas/v1/getPubKey`（只有 v1） |
| 验证码 | `GET /cas/getKaptchaStatus`、`GET /cas/kaptcha` |
| 登录成功跳转 | `POST /cas/login` → `/sso/zfiotlogin?ticket=…` → `/jwglxt/ticketlogin?uid=…` → `index_initMenu.html?jsdm=xs` |
| 姓名 / 学号 | `index_cxYhxxIndex.html?gnmkdm=index`（`.media-heading`）/ `index_initMenu.html`（`#sessionUserKey`） |
| 学期周次与开学日期 | `POST /jwglxt/kbcx/xskbcxZccx_cxZcByXnxq.html`（`xnm`,`xqm`）→ `[{zs,zcrq}]`，第 1 周日期即开学日期 |
| 节次时间 | `POST /jwglxt/jzgl/skxxMobile_cxRsdjc.html`（`xnm`,`xqm`,`xqh_id`）→ `[{jcmc,qssj,jssj}]` |
| 校区号来源 | `POST /jwglxt/kbcx/xskbcxMobile_cxXsKb.html`（`kblx=2`）的 `kbList[].xqh_id`，取不到时由学校接口按默认时段返回 |
| 周次课表页面 | `/jwglxt/kbcx/xskbcxZccx_cxXskbcxIndex.html?gnmkdm=N2154&layout=default` |

实测：2026-2027-1 第 1 周为 2026-08-31～09-06（共 20 周）；节次 1=08:20–09:05、
2=09:10–09:55、3=10:25–11:10、4=11:15–12:00、5=14:00–14:45、6=14:50–15:35 等，共 12 节。

## 认证加密

学校 `themes/xnly/js/cas.js`：`RSAUtils.encryptedString(key, 密码倒序)`——
UTF-16 码元倒序 → 按 `chunkSize = 2×(模数 16 位数字个数−1)` 补零分块 → 块内小端 16 位数字组成大整数 →
`m^e mod n` 教科书式 RSA（无 PKCS#1 填充）→ 十六进制。插件实现与 `security.js` 逐字节一致（本地对拍）。

## 校历作息行为

`study.calendar(termId)` 返回 `{termId, startDate, periods:[{number,start,end}]}`：

1. 由 `termId`（`YYYY-YYYY-S`）换算 `xnm` 与 `xqm`（1→3，2→12，3→16）；
2. 取该学期周次首周日期作为 `startDate`；
3. 取本校 12 节次真实起止时间作为 `periods`；接口异常时返回空 `periods`，App 继续使用已有设置。

> App 只在用户没有手动改过节次时间时应用插件提供的作息（这是宿主行为）。
> 如果之前手动改过「课表设置 → 节次时间」，需要在那里恢复默认/清除该账号的节次设置，插件值才会生效。

## 风控锁定（1.1.1）

学校统一认证对短时间多次登录会判「登录异常」并锁定账号，约 30 分钟自动解锁（会发短信）。
1.1.1 在收到 HTTP 423（Locked）时返回 **WEB_LOGIN_REQUIRED**（需要人工登录）而不是可重试错误，
这样宿主不会在锁定期间自动续登反复提交登录；错误文案会提示「约 30 分钟后自动解锁，请等待后重新登录」。

> 课表刷新本身只请求教务接口，不会登录。只有教务会话失效、且 CAS 会话也失效时才会提交一次密码登录；
> App 对自动续登有单飞合并和失败后 60 秒冷却。

## 验证范围

- 真实登录链路、课表接口、周次与节次接口均已实测（2026-11-13）。
- 离线 19 条样本覆盖（含 423 锁定转人工登录）认证全部入口、CAS 退回重试、验证码、限流、二次认证交接、
  网页登录后核验、身份回退、会话失效、过期续接，以及校历作息的正常/空周次/接口异常回退。
- 待真机复验：App 课表页节次时间显示、学期切换、成绩/考试与选退课。
- 测试期间多次登录触发过学校统一认证的临时限流（HTTP 423），等待一段时间即恢复。

## 安装

1. App「插件中心 → 更多 → 导入、回滚与开发工具」，下滑开启 **开发者模式**；
2. 「导入适配包」选择 `cn.edu.swfu.academic-1.1.0.eduplugin`；
3. 若提示「已验证并暂存」，到「插件中心 → 已安装」应用新版本；
4. 进入课表页下拉刷新一次，查看节次时间是否变为 08:20–09:05 等真实时间。

## 许可

GPL-3.0-only。参考同生态已发布插件的扩展结构与错误处理约定，实现按本校实际响应重写；
样本与交付包不含账号、密码、Cookie 或学生数据。
